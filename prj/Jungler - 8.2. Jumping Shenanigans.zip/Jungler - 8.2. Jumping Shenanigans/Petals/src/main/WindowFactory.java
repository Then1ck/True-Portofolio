package main;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class WindowFactory {
	public JFrame createWindow(JPanel panel, boolean FullScreen) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		
		window.setUndecorated(FullScreen);
		
		window.add(panel);
		window.pack();

		window.setLocationRelativeTo(null);
		
		window.setVisible(true);
		
		return window;
	}
}
