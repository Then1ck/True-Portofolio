package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

import cameras.Camera;
import controls.InputControls;
import controls.KeyboardCtrl;
import controls.MouseCtrl;
import controls.MouseMovementCtrl;
import controls.MouseWheelCtrl;
import scenes.Game;
import scenes.Scene;

@SuppressWarnings("serial")
public class WindowPanel extends JPanel implements Runnable{
	private JFrame Window;
	private WindowFactory WindowMaker = new WindowFactory();
	
	private int ScreenWidth = 1280, ScreenHeight = 720;
	private boolean FullScreen = false;
	private double FullScale;
	private Thread gameThread;
	
	private Scene curScene = null;
	private int FPS = 60;
	
	private KeyboardCtrl KeyboardInputs = new KeyboardCtrl();
	private MouseCtrl MouseInputs = new MouseCtrl();
	private MouseMovementCtrl MouseMoves = new MouseMovementCtrl();
	private MouseWheelCtrl MouseWheel = new MouseWheelCtrl();
	private InputControls IC;
	
	public WindowPanel() {
		Dimension MaxScreen = Toolkit.getDefaultToolkit().getScreenSize();
		System.out.println(MaxScreen.width + " " + MaxScreen.height);
		FullScale = (double)MaxScreen.width/(double)ScreenWidth;
		
		this.setPreferredSize(new Dimension(ScreenWidth, ScreenHeight));
		this.setBackground(Color.lightGray);
		
		this.setFocusable(true);
		this.setDoubleBuffered(true);
		
		System.out.println(FullScale);
		
		Window = WindowMaker.createWindow(this, FullScreen);
		
		this.addKeyListener(KeyboardInputs);
		this.addMouseListener(MouseInputs);
		this.addMouseMotionListener(MouseMoves);
		this.addMouseWheelListener(MouseWheel);
		
		IC = new InputControls(KeyboardInputs);
		curScene = new Game(KeyboardInputs, ScreenWidth, ScreenHeight, IC);
		
		startGameThread();
	}

	public void NewWindow() {
		Window.dispose();
		if(FullScreen) {
			FullScreen = false;
			this.setPreferredSize(new Dimension(ScreenWidth, ScreenHeight));
		}else {
			FullScreen = true;
			this.setPreferredSize(new Dimension((int)(ScreenWidth*FullScale), (int)(ScreenHeight*FullScale)));
		}
		Window = WindowMaker.createWindow(this, FullScreen);
	}
	
	private void startGameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}

	public void update() {
		curScene.update();
		
		if(IC.pausePressed) {
			NewWindow();
		}
		
//		System.out.println(KeyEvent.getKeyText(KeyEvent.VK_SPACE));
		
//		if(KeyboardInputs.getKeyHeld(KeyEvent.VK_W)) {
//			System.out.print("W ");
//		}
//		if(KeyboardInputs.getKeyHeld(KeyEvent.VK_A)) {
//			System.out.print("A ");
//		}
//		if(KeyboardInputs.getKeyHeld(KeyEvent.VK_S)) {
//			System.out.print("S ");
//		}
//		if(KeyboardInputs.getKeyHeld(KeyEvent.VK_D)) {
//			System.out.print("D ");
//		}
//		
//		if(MouseInputs.getButtonPressed(MouseEvent.BUTTON1)) {
//			System.out.println("M1 ");
//		}
//		System.out.println();
		

		KeyboardInputs.reset();
		MouseInputs.reset();
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		if(FullScreen)g2.scale(FullScale, FullScale);
		
		curScene.draw(g2);

//		g2.setFont(new Font("Arial", Font.BOLD, 24));
//		g2.setFont(new Font("Times New Roman", Font.BOLD, 24));
//		if(curScene instanceof Game) {
//			g2.drawString("curScene: " + curScene.getClass().getSimpleName(), 20+((Game)curScene).getCamX(), 30+((Game)curScene).getCamY()); // Draw text at x=20, y=30	
//		}
//		g2.dispose();
		
	}
	
	@Override
	public void run() {
		double DrawSpeed = 1000000000/FPS;
		double delta = 0;
		long oldTime = System.nanoTime();
		long newTime = System.nanoTime();
		System.out.println("Game, Start!");
		
		while(gameThread!=null) {
			newTime = System.nanoTime();
			delta += (newTime - oldTime)/DrawSpeed;
			oldTime = newTime;
			if(delta>=1) {
				update();
				repaint();
				delta--;
			}
		}
		
	}
}
