package main;

public class Main {

	public static void main(String[] args) {
		new WindowPanel();

	}

}

//TODO: Particle Generator, Map Art, Map Data, Crouch Art, Other Critters
//TODO: Pause [ScreenSize, ControlChange], SlowFall, maxFallSpeed
//TODO: Pause [Animation Update]