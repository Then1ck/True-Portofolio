package checks;

import java.awt.Point;

public class Intersect {

	public static boolean doOverlap(Point l1, Point r1, Point l2, Point r2)
	{
//		System.out.println(l1.x + " " + l1.y + " " + l2.x + " " + l2.y + " "
//				+ r1.x + " " + r1.y + " " + r2.x + " " + r2.y);
		
	   if (l1.x > r2.x || l2.x > r1.x)
	        return false;

	    // If one rectangle is above the other
	    if (r1.y < l2.y || r2.y < l1.y)
	        return false;

	    return true;
	}
	
	public static boolean Floor(Point l1, Point r1, Point l2, Point r2) {
//		System.out.println(l1.x + " " + l1.y + " " + l2.x + " " + l2.y + " "
//				+ r1.x + " " + r1.y + " " + r2.x + " " + r2.y);
		if (l1.x > r2.x || l2.x > r1.x)
	        return false;

	    // If one rectangle is above the other
		if (r1.y < l2.y || r2.y < l1.y) {
//			System.out.println("Top bottom");
	        return false;
		}

	    return true;
	}
	public static boolean Walls(Point l1, Point r1, Point l2, Point r2)
	{
//		System.out.println(l1.x + " " + l1.y + " " + l2.x + " " + l2.y + " "
//				+ r1.x + " " + r1.y + " " + r2.x + " " + r2.y);
		
	   if (l1.x > r2.x || l2.x > r1.x)
	        return false;

	    // If one rectangle is above the other
	    if (r1.y < l2.y || r2.y < l1.y)
	        return false;

	    return true;
	}
	
	public static boolean Ceilings(Point l1, Point r1, Point l2, Point r2)
	{
//		System.out.println(l1.x + " " + l1.y + " " + l2.x + " " + l2.y + " "
//				+ r1.x + " " + r1.y + " " + r2.x + " " + r2.y);
		
	   if (l1.x > r2.x || l2.x > r1.x)
	        return false;

	    // If one rectangle is above the other
	    if (r1.y < l2.y || r2.y < l1.y)
	        return false;

	    return true;
	}
	
	
}
