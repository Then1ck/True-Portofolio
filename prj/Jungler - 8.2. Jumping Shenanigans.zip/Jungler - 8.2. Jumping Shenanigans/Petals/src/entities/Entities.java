package entities;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import terrain.Room;

public abstract class Entities {
	protected int locX;
	protected int locY;
	protected int velX;
	protected int velY;
	private BufferedImage sprite = null;
	
	public Entities(int locX, int locY, BufferedImage Sprite) {
		super();
		this.locX = locX;
		this.locY = locY;
		this.velX = 0;
		this.velY = 0;
		
		sprite = Sprite;
	}
	public int getVelX() {
		return velX;
	}
	public void setVelX(int velX) {
		this.velX = velX;
	}
	public int getVelY() {
		return velY;
	}
	public void setVelY(int velY) {
		this.velY = velY;
	}
	public int getLocX() {
		return locX;
	}
	public void setLocX(int locX) {
		this.locX = locX;
	}
	public int getLocY() {
		return locY;
	}
	public void setLocY(int locY) {
		this.locY = locY;
	}
	public BufferedImage getSprite() {
		return sprite;
	}
	public void setSprite(BufferedImage sprite) {
		this.sprite = sprite;
	}
	
	public abstract void draw(Graphics2D g2);
	public abstract void update();
	public abstract void updateRoom(Room room);
	
	public int getX() {
		return locX;
	}
	public int getY() {
		return locY;
	}
	
}
