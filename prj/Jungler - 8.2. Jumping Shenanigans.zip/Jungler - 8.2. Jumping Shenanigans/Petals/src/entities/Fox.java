package entities;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import animations.Animates;
import animations.AnimationDrawer;
import animations.LoopAnimation;
import animations.NextAnimation;
import checks.Intersect;
import controls.InputControls;
import controls.KeyboardCtrl;
import particles.ParticleManager;
import scenes.Game;
import terrain.Ceiling;
import terrain.Ground;
import terrain.MapReader;
import terrain.Platform;
import terrain.Portal;
import terrain.Room;
import terrain.Stairs;
import terrain.Wall;
import terrain.Water;

public class Fox extends Entities {
	private AnimationDrawer animation = null;
	private KeyboardCtrl KbI;
	private int jumpTime = 2;
	private boolean Grounded = false, left=false, Playable, Crouch = false, Lunge=false, Running=false, onWater=false;
	private int maxSlowFall=2, slowFall=maxSlowFall;
	private double Scale = 2;
	private int maxSpeed = 8;
	private int SpriteSizeX = 32, SpriteSizeY = 32;
	private int ScaledSpriteX = (int)(SpriteSizeX*Scale);
	private int ScaledSpriteY = (int)(SpriteSizeY*Scale);
	private ParticleManager PM = new ParticleManager();
	private int ParticleCounter=8, MaxParticleCounter = 8;
	private Room room;
	private Game game;
	private InputControls IC;

	public Fox(KeyboardCtrl kbI, boolean playable, Room room, Game game, InputControls ic) {
		super(0, 0, null);
		
		Playable = playable;
		KbI = kbI;
		
		IC = ic;
		
		this.room = room;
		this.game = game;
		
		BufferedImage temp = null;
		try {
			temp = ImageIO.read(getClass().getResourceAsStream("/critters/Fox.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<Animates> Animations = new ArrayList<Animates>();
		Animations.add(new LoopAnimation(temp, 0, 0, 128, 32, 10, SpriteSizeX, SpriteSizeY, Scale));
		Animations.add(new NextAnimation(temp, 0, 64, 128, 96, 3, SpriteSizeX, SpriteSizeY, Scale, 2));
		Animations.add(new LoopAnimation(temp, 96, 64, 128, 96, 1, SpriteSizeX, SpriteSizeY, Scale));
		Animations.add(new NextAnimation(temp, 0, 96, 128, 128, 3, SpriteSizeX, SpriteSizeY, Scale, 4));
		Animations.add(new LoopAnimation(temp, 96, 96, 128, 128, 1, SpriteSizeX, SpriteSizeY, Scale));
		Animations.add(new LoopAnimation(temp, 128, 0, 256, 64, 4, SpriteSizeX, SpriteSizeY, Scale));
		animation = new AnimationDrawer(Animations);
	}

	@Override
	public void draw(Graphics2D g2) {

		PM.draws(g2);
		g2.draw(new Rectangle(locX, locY-ScaledSpriteY, ScaledSpriteX, ScaledSpriteY));
		int tmp = animation.draw(g2, locX, locY, left);
		if(tmp!=-1) {
			animation.changeState(tmp);
		}
		
	}

	@Override
	public void update() {
		if(!Playable)return;
		
		if(IC.runHeld) {
			maxSpeed=12;
			animation.Animations.get(5).MaxCounter=2;
			Running=true;
		}else {
			maxSpeed=8;
			animation.Animations.get(5).MaxCounter=4;
			Running=false;
		}
		
		if(IC.downHeld&&Grounded) {
			Crouch=true;
			maxSpeed=4;
		}else {
			Crouch = false;
		}
		
		if(Lunge)maxSpeed=18;
		
		if(onWater)maxSpeed /= 2;
		
		
		boolean Moving = false;
		if (IC.rightHeld) {
			Moving = !Moving;
			if (velX < maxSpeed) velX++;
			else velX--;
			left = false;
		} 
		if (IC.leftHeld) {
			Moving = !Moving;
			if (velX > -maxSpeed) velX--;
			else velX++;
			left = true;
		} 
		if(!Moving) {
			if (velX > 0) velX--;
			else if (velX < 0) velX++;
			Running=false;
		}
//		System.out.println(Grounded);
		if(Grounded)Lunge=false;
		
		if(Running&&Grounded) {
			if(ParticleCounter==0) {
				ParticleCounter = MaxParticleCounter;
				PM.make(locX, locY, 0, left);
			}else {
				ParticleCounter--;	
			}
			
		}
		
		PM.removal();
		
		locX+=velX;
		

		
		for (Portal current : room.getPortalMap()) {

		    if (!canEnterFromDirection(current)) continue;

		    if (Intersect.doOverlap(
		        new Point(locX, locY - ScaledSpriteY),
		        new Point(locX + ScaledSpriteX, locY),
		        new Point(current.portalBox.x, current.portalBox.y),
		        new Point(current.portalBox.x + current.portalBox.width, current.portalBox.y + current.portalBox.height)
		    )) {
		        // Load the destination room
		        Room destRoom = new Room(new MapReader("res/maps/map" + current.nextRoom + ".txt"));
		        Portal destPortal = destRoom.getPortalMap().get(current.targetPortalIndex);

		        // Compute offset relative to portal box
		        int offsetX = locX - current.portalBox.x;
		        int offsetY = locY - current.portalBox.y;

		        // Clamp offset so it doesn't teleport out of bounds
		        offsetX = Math.max(0, Math.min(offsetX, destPortal.portalBox.width - ScaledSpriteX));
		        offsetY = Math.max(0, Math.min(offsetY, destPortal.portalBox.height));

		        locX = destPortal.portalBox.x + offsetX;
		        locY = destPortal.portalBox.y + offsetY;

		        game.updateRoom(current.nextRoom);
		        break;
		    }
		}
		
		for(Wall element : room.getWallMap()) {
			if(	Intersect.Walls(
				new Point(locX, locY-(int)(ScaledSpriteY)),
				new Point(locX+(int)(ScaledSpriteX), locY),
				new Point(element.wall.x, element.wall.y),
				new Point(element.wall.x+element.wall.width, element.wall.y+element.wall.height)
				)) {
					if(velX > 0) {
						locX = element.wall.x-ScaledSpriteX;
						velX = 0;
					}else if(velX < 0) {
						locX = element.wall.x+element.wall.width;
						velX = 0;
					}
				}
		}
		if(IC.upHeld) {
			if(!IC.upPressed&&Grounded) {
//				System.out.println("Error 1?: " + Grounded);
			}else {
				if(Grounded) {
					Grounded=false;
					jumpTime=7;	
				}
				if(IC.upPressed&&onWater){
					velY=0;
					jumpTime=4;
					Lunge=false;
				}
//					else System.out.println("Error 2?: "+Grounded);
				if(Running&&Crouch) {
					Lunge=true;
				}
			}
			if(jumpTime>0) {
				if(!Lunge) {
					velY-=3;
				}else {
					velY-=2;
					if(!left) {
						velX=velX+3>maxSpeed?maxSpeed:velX+3;
					}else if(left) {
						velX=velX-3<maxSpeed?-maxSpeed:velX-3;
					}
				}
				jumpTime--;
			}
		}else {
			jumpTime = 0;
		}

		locY+=velY;
		
		if(velY<0) {
			for(Ceiling element : room.getCeilingMap()) {
				if(	Intersect.Ceilings(
					new Point(locX, locY-(int)(ScaledSpriteY)),
					new Point(locX+(int)(ScaledSpriteX), locY),
					new Point(element.ceiling.x, element.ceiling.y),
					new Point(element.ceiling.x+element.ceiling.width, element.ceiling.y+element.ceiling.height)
					)) {
						locY = element.ceiling.y+element.ceiling.height+ScaledSpriteY;
						velY=0;
						break;
					}
			}
		}

		onWater = false;
		for(Water element : room.getWaterMap()) {
			if(Intersect.doOverlap(new Point(locX, locY-(int)(ScaledSpriteY)),
					new Point(locX+(int)(ScaledSpriteX), locY),
					new Point(element.waters.x, element.waters.y),
					new Point(element.waters.x+element.waters.width, element.waters.y+element.waters.height))) {
				onWater = true;
				
			}
		}
		
		//TODO: Maybe allow phasing through platforms. For now, lunge is better
//		System.out.println(Lunge);
		
		boolean StairHit = false;
		for(Stairs element : room.getStairMap()) {
			int surfaceY = element.getYOnSlope(locX+(int)(ScaledSpriteX/2));
			if(locX > element.stairBox.x+element.stairBox.width || locX+ScaledSpriteX < element.stairBox.x) {
				element.removeEntityOnStairs(this);
				continue;
			}
			//Ignores stairs while below
			if(locY >= surfaceY) {
				if(!element.onStairs.contains(this)) continue;
				if(velY > 0) {
					velY = 0;
					Grounded = true;
				}else Grounded = false;
				locY = surfaceY+velY;
				if(!Lunge&&IC.upPressed)jumpTime = 7;
			}else if(locY < surfaceY) {
				element.addEntityOnStairs(this);
//				if(((velY > 0 && element.direction==1) || (velY < 0 && element.direction==2))&&Grounded) {
//					jumpTime = 7;
//				}
				if(Grounded&&IC.upPressed) {
					jumpTime=7;
//					Grounded = false;
				}
			}
//			if(velY < 0)element.removeEntityOnStairs(this);
//			if(element.onStairs.contains(this))locY = surfaceY;
			
			if(element.onStairs.contains(this))StairHit = true;
		}
		
		boolean GroundHit = false;
		if(velY>=0 && !StairHit) {
			for(Ground element : room.getGroundMap()) {
				if(	Intersect.Floor(
				new Point(locX, locY-(int)(ScaledSpriteY)),
				new Point(locX+(int)(ScaledSpriteX), locY),
				new Point(element.ground.x, element.ground.y),
				new Point(element.ground.x+element.ground.width, element.ground.y+element.ground.height)
				)) {
//					if(locY - velY < element.ground.y)continue;
//					System.out.println(locY + " " + velY + " " + element.ground.y);
					GroundHit=true;
					locY = element.ground.y;
				}
			}
			
			for(Platform element : room.getPlatformMap()) {
				if(locX > element.platform.x+element.platform.width || locX+ScaledSpriteX < element.platform.x
				|| locY-ScaledSpriteY > element.platform.y+element.platform.height) {
					element.removeEntityOnGround(this);
					continue;
				}
				if(locY <= element.platform.y)element.addEntityOnGround(this);
				if(element.onGround.contains(this) && locY >= element.platform.y) {
					GroundHit=true;
					locY = element.platform.y;
				}
			}
			
			if(GroundHit) {
				if(velY>0)velY=0;
				Grounded=true;
			}else {
				Grounded=false;
			}
		}
		
		if(!GroundHit) {
			velY++;
			if(onWater&&slowFall!=0) {
				velY--;
				slowFall--;
			}else if(slowFall==0)slowFall=maxSlowFall;
		}
		
		
		if(Grounded) {
			if(Moving)animation.changeState(5);
			else animation.changeState(0);
		}else {
			if(velY < 0)animation.changeState(1);
			else animation.changeState(3);
		}

	}

	@Override
	public void updateRoom(Room room) {
		this.room = room;
		this.PM.clear();
	}
	
	private boolean canEnterFromDirection(Portal p) {
	    switch (p.Direction) {
	        case 1: return velX > 0; // from left
	        case 2: return velX < 0; // from right
	        case 3: return velY > 0; // from top
	        case 4: return velY < 0; // from bottom
	        default: return true;
	    }
	}
	
	
}
