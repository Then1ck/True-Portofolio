package entities;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import terrain.Room;

public class Bats extends Entities {

	public Bats() {
		super(0, 0, null);
	}

	@Override
	public void draw(Graphics2D g2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRoom(Room room) {
		// TODO Auto-generated method stub
		
	}

}
