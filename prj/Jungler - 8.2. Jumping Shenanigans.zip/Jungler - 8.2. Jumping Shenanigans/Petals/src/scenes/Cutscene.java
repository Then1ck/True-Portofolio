package scenes;

import java.awt.Graphics2D;

public class Cutscene extends Scene{

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw(Graphics2D g2) {
		// TODO Auto-generated method stub
		
	}

}
