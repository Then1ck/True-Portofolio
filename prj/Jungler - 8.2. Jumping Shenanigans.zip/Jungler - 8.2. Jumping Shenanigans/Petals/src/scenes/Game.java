package scenes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import cameras.Camera;
import cameras.CameraBoundsLoader;
import controls.InputControls;
import controls.KeyboardCtrl;
import entities.Entities;
import entities.Fox;
import terrain.Ceiling;
import terrain.Ground;
import terrain.MapReader;
import terrain.Platform;
import terrain.Portal;
import terrain.Room;
import terrain.Stairs;
import terrain.Wall;
import terrain.Water;

public class Game extends Scene{
	
	private Entities player;
	private KeyboardCtrl KbI;
	private int RoomNumber = 2;
	MapReader reader = new MapReader("res/maps/map" + RoomNumber + ".txt");	
	private Room room;
	private InputControls IC;
	private Camera cams;
	
	
	public Game(KeyboardCtrl KeyboardInputs, int ScreenWidth, int ScreenHeight, InputControls ic) {
		KbI = KeyboardInputs;
		IC = ic;
		
		cams = new Camera(ScreenWidth, ScreenHeight);
		
		room = new Room(reader);
		
		player = new Fox(KbI, true, room, this, IC);
	}
	
	public int getCamX() {
		return cams.getX();
	}
	public int getCamY() {
		return cams.getY();
	}
	
	public void paused() {
		
	}
	
	public void pausedDraw(Graphics2D g2) {
		g2.translate(cams.getX(), cams.getY());
		g2.setFont(new Font("Times New Roman", Font.BOLD, 32));
		g2.drawString("PAUSED", 16, 32);
	}
	
	@Override
	public void update() {
		IC.ProcessInputs();
		if(KbI.getKeyHeld(KeyEvent.VK_P)) {
			paused();
			return;
		}
		
		player.update();

		if (!room.getCameraMap().isEmpty()) {
		    cams.setBounds(room.getCameraMap().get(0)); // Always use first bound
		}
		
		cams.update(player.getLocX(), player.getLocY());
	}

	@Override
	public void draw(Graphics2D g2) {
		g2.translate(-cams.getX(), -cams.getY());
		
		if(KbI.getKeyHeld(KeyEvent.VK_P)) {
			pausedDraw(g2);
			return;
		}
		
		player.draw(g2);
		
		for(Ground element : room.getGroundMap()) {
			g2.draw(element.ground);
		}
		
		g2.setColor(Color.darkGray);
		for(Platform element : room.getPlatformMap()) {
			g2.draw(element.platform);
		}
		
		g2.setColor(Color.blue);
		for(Wall element : room.getWallMap()) {
			g2.draw(element.wall);
		}
		
		g2.setColor(Color.cyan);
		for(Water element : room.getWaterMap()) {
			g2.draw(element.waters);
		}
		
		g2.setColor(Color.red);
		for(Ceiling element : room.getCeilingMap()) {
			g2.draw(element.ceiling);
		}
		
		g2.setColor(Color.yellow);
		for(Rectangle element : room.getCameraMap()) {
			g2.draw(element);
		}
		
		g2.setColor(Color.green);
		for(Portal element : room.getPortalMap()) {
			g2.draw(element.portalBox);
		}
		
		g2.setColor(Color.orange);
		for (Stairs element : room.getStairMap()) {
		    g2.draw(element.stairBox);
		    if(element.direction==1) {
			    g2.drawLine(element.stairBox.x, element.stairBox.y+element.stairBox.height, 
			    		element.stairBox.x+element.stairBox.width, element.stairBox.y);	
		    }else g2.drawLine(element.stairBox.x, element.stairBox.y, 
		    		element.stairBox.x+element.stairBox.width, element.stairBox.y+element.stairBox.height);	
		}
	}

	public void updateRoom(int number) {
	    RoomNumber = number;
	    reader = new MapReader("res/maps/map" + RoomNumber + ".txt");
	    room = new Room(reader);
	    player.updateRoom(room);
	    

	    // Update camera bound
	    if (!room.getCameraMap().isEmpty()) {
	        cams.setBounds(room.getCameraMap().get(0));
	        cams.cutTo(player.getLocX(), player.getLocY()); // Cut camera to player
	    }
	}

	
}
