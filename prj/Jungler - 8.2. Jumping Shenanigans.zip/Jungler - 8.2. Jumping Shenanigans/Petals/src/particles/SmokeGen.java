package particles;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import animations.FinAnimation;
import animations.LoopAnimation;

public class SmokeGen extends ParticleGen{

	private boolean left;
	public SmokeGen() {
		super(0, 0, 32, 32, 0, 0, 64, 64, 2, 5);
		
		try {
			ParticleSheet = ImageIO.read(getClass().getResourceAsStream("/particleasset/SmokeTrail.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


	@Override
	public FinAnimation createAnimation(int locX, int locY, boolean left) {
		FinAnimation ParticleAnimation = new FinAnimation(ParticleSheet, startX, startY, endX, endY, maxCounter, spriteSizeX, spriteSizeY, Scale, locX, locY-ScaledSpriteX, left);
		return ParticleAnimation;
	}
	
	@Override
	public FinAnimation createAnimation() {
		FinAnimation ParticleAnimation = new FinAnimation(ParticleSheet, startX, startY, endX, endY, maxCounter, spriteSizeX, spriteSizeY, Scale, locX, locY, left);
		return ParticleAnimation;
	}

}
