package particles;

import java.awt.image.BufferedImage;

import animations.FinAnimation;

public abstract class ParticleGen {
	protected int locX, locY, spriteSizeX, spriteSizeY, startX, startY, endX, endY, Counter, maxCounter, ScaledSpriteX, ScaledSpriteY, X, Y;
	protected double Scale;
	protected BufferedImage ParticleSheet = null;
	
	public ParticleGen(int locX, int locY, int spriteSizeX, int spriteSizeY, int startX, int startY, int endX, int endY,
			double scale, int maxCounter) {
		super();
		this.locX = locX;
		this.locY = locY;
		this.spriteSizeX = spriteSizeX;
		this.spriteSizeY = spriteSizeY;
		this.startX = startX;
		this.startY = startY;
		this.endX = endX;
		this.endY = endY;
		Scale = scale;
		ScaledSpriteX = (int)(spriteSizeX*Scale);
		ScaledSpriteY = (int)(spriteSizeY*Scale);
		this.maxCounter = maxCounter;
		X = startX;
		Y = startY;
	}
	
	public abstract FinAnimation createAnimation(int locX, int locY, boolean left);
	public abstract FinAnimation createAnimation();
}
	