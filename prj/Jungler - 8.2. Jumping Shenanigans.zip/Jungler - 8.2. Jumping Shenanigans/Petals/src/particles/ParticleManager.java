package particles;

import java.awt.Graphics2D;
import java.util.ArrayList;

import animations.FinAnimation;
import animations.LoopAnimation;

public class ParticleManager {
	private ArrayList<ParticleGen> ParticleList = new ArrayList<ParticleGen>();
	private ArrayList<FinAnimation> OnQueue = new ArrayList<FinAnimation>();
	private ArrayList<FinAnimation> DelQueue = new ArrayList<FinAnimation>();
	
	public ParticleManager() {
		ParticleList.add(new SmokeGen());
	}
	
	public void make(int locX, int locY, int type, boolean left) {
		OnQueue.add(ParticleList.get(type).createAnimation(locX, locY, left));
	}
	
	public void draws (Graphics2D g2) {
		for(FinAnimation element : OnQueue) {
			if(element.drawR(g2, element.locX, element.locY)==1)DelQueue.add(element);
		}
	}
	
	public void removal() {
		for(FinAnimation element : DelQueue) {
			OnQueue.remove(element);
		}
		DelQueue.clear();
	}
	
	public void clear() {
		OnQueue.clear();
	}
	
}
