package controls;

public class Buttons {
	private boolean Pressed, Held, Released, toPress, toRelease;
	
	public Buttons() {
		Pressed = false;
		Held = false;
		Released = false;
		toPress = true;
		toRelease = false;
	}
	
	public boolean getButtonPress() {
		return Pressed;
	}
	
	public boolean getButtonHeld() {
		return Held;
	}
	
	public boolean getButtonReleased() {
		return Released;
	}
	
	public void Reset() {
		Pressed = false;
		Released = false;
	}
	
	public void Presses() {
		if(toPress) {
			Pressed = true;
			Held = true;
			toPress = false;
			toRelease = true;
		}
	}
	
	public void Releases() {
		if(toRelease) {
			Released = true;
			Held = false;
			toRelease = false;
			toPress = true;
		}
	}
}
