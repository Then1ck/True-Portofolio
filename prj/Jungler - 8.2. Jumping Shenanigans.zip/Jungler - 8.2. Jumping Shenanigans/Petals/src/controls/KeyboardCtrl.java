package controls;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;
import java.util.Map;

public class KeyboardCtrl implements KeyListener {
    private Map<Integer, Buttons> keys = new HashMap<>();

    @Override
    public void keyTyped(KeyEvent e) {
    	
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getExtendedKeyCode();
        keys.computeIfAbsent(keyCode, k -> new Buttons()).Presses();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getExtendedKeyCode();
        keys.computeIfAbsent(keyCode, k -> new Buttons()).Releases();
    }

    public void reset() {
        for (Buttons btn : keys.values()) {
            btn.Reset();
        }
    }

    public boolean getKeyPressed(int keyCode) {
        Buttons btn = keys.get(keyCode);
        return btn != null && btn.getButtonPress();
    }

    public boolean getKeyHeld(int keyCode) {
        Buttons btn = keys.get(keyCode);
        return btn != null && btn.getButtonHeld();
    }
}
