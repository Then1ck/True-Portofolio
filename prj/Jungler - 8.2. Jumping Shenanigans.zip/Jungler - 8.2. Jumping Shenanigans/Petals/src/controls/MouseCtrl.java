package controls;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;

public class MouseCtrl implements MouseListener{
    private Map<Integer, Buttons> keys = new HashMap<>();

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
        int keyCode = e.getButton();
        keys.computeIfAbsent(keyCode, k -> new Buttons()).Presses();
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
        int keyCode = e.getButton();
        keys.computeIfAbsent(keyCode, k -> new Buttons()).Releases();
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public boolean getButtonPressed(int keyCode) {
        Buttons btn = keys.get(keyCode);
        return btn != null && btn.getButtonPress();
    }
	
	public boolean getButtonHeld(int keyCode) {
        Buttons btn = keys.get(keyCode);
        return btn != null && btn.getButtonHeld();
    }
	
	public void reset() {
        for (Buttons btn : keys.values()) {
            btn.Reset();
        }
    }

}
