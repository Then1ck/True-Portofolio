package controls;

public class MouseMap {

}
