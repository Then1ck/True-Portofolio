package controls;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class MouseMovementCtrl implements MouseMotionListener{

	@Override
	public void mouseDragged(MouseEvent e) {
		System.out.println(e.getX() + " " + e.getY());
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		System.out.println(e.getX() + " " + e.getY());
		
	}

}
