package controls;

import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class InputControls {
	private KeyboardCtrl KbI;
	public boolean leftHeld, leftPressed, rightHeld, rightPressed, upHeld, upPressed, downHeld, downPressed, runHeld, runPressed, 
	attHeld, attPressed, pausePressed, pauseHeld;
	private Set<Integer> leftKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_A, KeyEvent.VK_LEFT));
	private Set<Integer> rightKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_D, KeyEvent.VK_RIGHT));
	private Set<Integer> upKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_W, KeyEvent.VK_UP, KeyEvent.VK_SPACE));
	private Set<Integer> downKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_S, KeyEvent.VK_DOWN, KeyEvent.VK_CONTROL));
	private Set<Integer> runKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_SHIFT));
	private Set<Integer> attKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_ENTER));
	private Set<Integer> pauseKeys = new HashSet<>(Arrays.asList(KeyEvent.VK_ESCAPE));

	public InputControls(KeyboardCtrl kbI) {
		super();
		KbI = kbI;
	}
	
	public void ProcessInputs() {
		leftHeld = isAnyKeyHeld(leftKeys);
		leftPressed = isAnyKeyPressed(leftKeys);

		rightHeld = isAnyKeyHeld(rightKeys);
		rightPressed = isAnyKeyPressed(rightKeys);

		upHeld = isAnyKeyHeld(upKeys);
		upPressed = isAnyKeyPressed(upKeys);

		downHeld = isAnyKeyHeld(downKeys);
		downPressed = isAnyKeyPressed(downKeys);

		runHeld = isAnyKeyHeld(runKeys);
		runPressed = isAnyKeyPressed(runKeys);

		attHeld = isAnyKeyHeld(attKeys);
		attPressed = isAnyKeyPressed(attKeys);
		
		pauseHeld = isAnyKeyHeld(pauseKeys);
		pausePressed = isAnyKeyPressed(pauseKeys);
	}
	
	private boolean isAnyKeyHeld(Set<Integer> keys) {
		for (int key : keys) {
			if (KbI.getKeyHeld(key)) return true;
		}
		return false;
	}

	private boolean isAnyKeyPressed(Set<Integer> keys) {
		for (int key : keys) {
			if (KbI.getKeyPressed(key)) return true;
		}
		return false;
	}

	
}
