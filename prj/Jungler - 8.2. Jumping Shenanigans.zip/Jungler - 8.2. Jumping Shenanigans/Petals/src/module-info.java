/**
 * 
 */
/**
 * 
 */
module Petals {
	requires java.desktop;
}