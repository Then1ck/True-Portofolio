package cameras;

import java.awt.Rectangle;

public class Camera {
    private double x, y;
    private double lerpSpeed = 0.1;

    private int screenWidth, screenHeight;
    private Rectangle currentBounds;

    public Camera(int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }

    public void setBounds(Rectangle bounds) {
        this.currentBounds = bounds;
    }

    public void update(double targetX, double targetY) {
        double targetCamX = targetX - screenWidth / 2.0;
        double targetCamY = targetY - screenHeight / 2.0;

        x += (targetCamX - x) * lerpSpeed;
        y += (targetCamY - y) * lerpSpeed;

        if (currentBounds != null) {
            // Clamp camera within bounds
            x = Math.max(currentBounds.x, Math.min(x, currentBounds.x + currentBounds.width - screenWidth));
            y = Math.max(currentBounds.y, Math.min(y, currentBounds.y + currentBounds.height - screenHeight));
        }
    }

    public int getX() {
        return (int) x;
    }

    public int getY() {
        return (int) y;
    }
    
    public void cutTo(double targetX, double targetY) {
        x = targetX - screenWidth / 2.0;
        y = targetY - screenHeight / 2.0;

        if (currentBounds != null) {
            int minX = currentBounds.x;
            int maxX = currentBounds.x + currentBounds.width - screenWidth;
            int minY = currentBounds.y;
            int maxY = currentBounds.y + currentBounds.height - screenHeight;

            x = Math.max(minX, Math.min(x, maxX));
            y = Math.max(minY, Math.min(y, maxY));
        }
    }

}
