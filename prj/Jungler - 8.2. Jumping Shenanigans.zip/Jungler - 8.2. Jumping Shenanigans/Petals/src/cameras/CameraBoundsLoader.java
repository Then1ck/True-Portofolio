package cameras;

import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CameraBoundsLoader {
    public static ArrayList<Rectangle> loadBounds(String path) {
        ArrayList<Rectangle> bounds = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length != 4) continue;

                int x = Integer.parseInt(parts[0].trim());
                int y = Integer.parseInt(parts[1].trim());
                int w = Integer.parseInt(parts[2].trim());
                int h = Integer.parseInt(parts[3].trim());

                bounds.add(new Rectangle(x, y, w, h));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bounds;
    }
}
