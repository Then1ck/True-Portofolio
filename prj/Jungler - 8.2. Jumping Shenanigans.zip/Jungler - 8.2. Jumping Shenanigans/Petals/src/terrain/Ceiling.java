package terrain;

import java.awt.Rectangle;

public class Ceiling {
	public Rectangle ceiling;

	public Ceiling(Rectangle ceiling) {
		super();
		this.ceiling = ceiling;
	}
	
	
}
