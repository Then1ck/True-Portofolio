package terrain;

import java.awt.Rectangle;

public class Wall {
	public Rectangle wall;

	public Wall(Rectangle wall) {
		super();
		this.wall = wall;
		
	}
	
}
