package terrain;

import java.awt.Rectangle;
import java.util.ArrayList;

public class Room {
	private ArrayList<Ground> GroundMap;
	private ArrayList<Wall> WallMap;
	private ArrayList<Ceiling> CeilingMap;
	private ArrayList<Rectangle> CameraMap;
	private ArrayList<Portal> PortalMap;
	private ArrayList<Stairs> StairMap;
	private ArrayList<Platform> PlatformMap;
	private ArrayList<Water> WaterMap;
	
	public Room(MapReader reader) {
		GroundMap = reader.getGrounds();
		WallMap = reader.getWalls();
		CeilingMap = reader.getCeilings();
		CameraMap = reader.getBounds();
		PortalMap = reader.getPortals();
		StairMap = reader.getStairs();
		PlatformMap = reader.getPlatforms();
		WaterMap = reader.getWaters();
	}
	
	public ArrayList<Ground> getGroundMap() {
		return GroundMap;
	}
	public ArrayList<Wall> getWallMap() {
		return WallMap;
	}
	public ArrayList<Ceiling> getCeilingMap() {
		return CeilingMap;
	}
	public ArrayList<Rectangle> getCameraMap() {
		return CameraMap;
	}
	public ArrayList<Portal> getPortalMap() {
		return PortalMap;
	}
	public ArrayList<Stairs> getStairMap() {
		return StairMap;
	}
	public ArrayList<Platform> getPlatformMap() {
		return PlatformMap;
	}
	public ArrayList<Water> getWaterMap() {
		return WaterMap;
	}
	
}
