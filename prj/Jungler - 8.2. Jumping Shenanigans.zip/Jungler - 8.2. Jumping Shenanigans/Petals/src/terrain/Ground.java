package terrain;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;

import entities.Entities;

public class Ground {
	public Rectangle ground;
	public ArrayList<Entities> onGround = new ArrayList<Entities>();

	public Ground(Rectangle ground) {
		super();
		this.ground = ground;
		
	}
	
	public void draw(Graphics2D g2) {
		g2.draw(new Rectangle(ground.x, ground.y, ground.width, ground.height));
	}
	
	public void addEntityOnGround(Entities Thing) {
		if(!onGround.contains(Thing))
			onGround.add(Thing);
	}
	public void removeEntityOnGround(Entities Thing) {
		onGround.remove(Thing);
	}
}
