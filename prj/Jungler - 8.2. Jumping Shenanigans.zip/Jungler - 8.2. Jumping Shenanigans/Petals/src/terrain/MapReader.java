package terrain;

import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class MapReader {

	private ArrayList<Ground> grounds = new ArrayList<>();
	private ArrayList<Wall> walls = new ArrayList<>();
	private ArrayList<Ceiling> ceilings = new ArrayList<>();
	private ArrayList<Rectangle> cameras = new ArrayList<>();
	private ArrayList<Portal> portals = new ArrayList<>();
	private ArrayList<Stairs> stairs = new ArrayList<>();
	private ArrayList<Platform> platforms = new ArrayList<>();
	private ArrayList<Water> waters = new ArrayList<>();

	public MapReader(String path) {
		System.out.println("Iz here");
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			String line;
			String currentType = "";

			while ((line = br.readLine()) != null) {
				System.out.println(line);
				line = line.trim();
				if (line.isEmpty()) continue;

				// Parse rectangle values
				
				String[] parts = line.split(" ");
				switch(parts.length) {
					case 1: {
						currentType=line;
					}break;
					case 4: {
						int x = Integer.parseInt(parts[0]);
						int y = Integer.parseInt(parts[1]);
						int w = Integer.parseInt(parts[2]);
						int h = Integer.parseInt(parts[3]);
	
						Rectangle rect = new Rectangle(x, y, w, h);
	
						switch (currentType) {
							case "Grounds" -> grounds.add(new Ground(rect));
							case "Walls" -> walls.add(new Wall(rect));
							case "Ceiling" -> ceilings.add(new Ceiling(rect));
							case "Camera" -> cameras.add(new Rectangle(rect));
							case "Platform" -> platforms.add(new Platform(rect));
							case "Water" -> waters.add(new Water(rect));
						}
						break;
					}
					case 5: {
						int x = Integer.parseInt(parts[0]);
						int y = Integer.parseInt(parts[1]);
						int w = Integer.parseInt(parts[2]);
						int z = Integer.parseInt(parts[3]);
						int d = Integer.parseInt(parts[4]);
						
						stairs.add(new Stairs(new Rectangle(x, y, w, z), d));
						break;
					}
					case 7: {
						int x = Integer.parseInt(parts[0]);
						int y = Integer.parseInt(parts[1]);
						int w = Integer.parseInt(parts[2]);
						int h = Integer.parseInt(parts[3]);
						int i = Integer.parseInt(parts[4]);
						int j = Integer.parseInt(parts[5]);
						int k = Integer.parseInt(parts[6]);
	
						Rectangle rect = new Rectangle(x, y, w, h);
						portals.add(new Portal(rect, i, j, k));
						break;
					}
					
				}

				
			}

		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Failed");
		}
	}

	public ArrayList<Ground> getGrounds() {
		return grounds;
	}

	public ArrayList<Wall> getWalls() {
		return walls;
	}

	public ArrayList<Ceiling> getCeilings() {
		return ceilings;
	}
	
	public ArrayList<Rectangle> getBounds() {
		return cameras;
	}
	
	public ArrayList<Portal> getPortals() {
		return portals;
	}
	
	public ArrayList<Stairs> getStairs() {
		return stairs;
	}
	
	public ArrayList<Platform> getPlatforms() {
		return platforms;
	}
	
	public ArrayList<Water> getWaters() {
		return waters;
	}
}
