package terrain;

import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Portal {
	public Rectangle portalBox;
	public int nextRoom, targetPortalIndex, Direction;

	public Portal(Rectangle portalBox, int Room, int index, int direction) {
		super();
		this.portalBox = portalBox;
		nextRoom = Room;
		targetPortalIndex = index;
		Direction = direction;
	}
	
	public void draw(Graphics2D g2) {
		g2.draw(new Rectangle(portalBox.x, portalBox.y, portalBox.width, portalBox.height));
	}
}
