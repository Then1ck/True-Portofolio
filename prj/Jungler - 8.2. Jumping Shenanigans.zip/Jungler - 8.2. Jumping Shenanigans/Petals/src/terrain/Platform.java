package terrain;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;

import entities.Entities;

public class Platform {
	public Rectangle platform;
	public ArrayList<Entities> onGround = new ArrayList<Entities>();

	public Platform(Rectangle ground) {
		super();
		this.platform = ground;
		
	}
	
	public void draw(Graphics2D g2) {
		g2.draw(new Rectangle(platform.x, platform.y, platform.width, platform.height));
	}
	
	public void addEntityOnGround(Entities Thing) {
		if(!onGround.contains(Thing))
			onGround.add(Thing);
	}
	public void removeEntityOnGround(Entities Thing) {
		onGround.remove(Thing);
	}
}
