package terrain;

import java.awt.Rectangle;
import java.util.ArrayList;

import entities.Entities;

public class Stairs {
    public Rectangle stairBox;
    public int direction; // 1 = right, 2 = left
    public ArrayList<Entities> onStairs = new ArrayList<Entities>();
    
    public Stairs(Rectangle box, int direction) {
        this.stairBox = box;
        this.direction = direction;
    }

    // Given an x within stairBox, return corresponding y on the slope
    public int getYOnSlope(int x) {
        float progress = (float)(x - stairBox.x) / stairBox.width;
        progress = Math.max(0, Math.min(1, progress));

        if (direction == 2) progress = 1 - progress;

        return (int)(stairBox.y + stairBox.height * (1 - progress));
    }
    public boolean isWithinX(int x) {
        return x >= stairBox.x && x <= stairBox.x + stairBox.width;
    }
    public int getXOnSlope(int y) {
        float progress = (float)(y - stairBox.y) / stairBox.height;
        progress = Math.max(0, Math.min(1, progress));

        if (direction == 2) progress = 1 - progress;

        return (int)(stairBox.x + stairBox.width * progress);
    }

    public void addEntityOnStairs(Entities Things) {
    	if(!onStairs.contains(Things))
    		onStairs.add(Things);
    }
    public void removeEntityOnStairs(Entities Things) {
    	onStairs.remove(Things);
    }

}
