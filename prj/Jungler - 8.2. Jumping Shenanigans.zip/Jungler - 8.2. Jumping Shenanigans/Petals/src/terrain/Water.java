package terrain;

import java.awt.Rectangle;

public class Water {
	public Rectangle waters;

	public Water(Rectangle waters) {
		super();
		this.waters = waters;
	}
	
	
}
