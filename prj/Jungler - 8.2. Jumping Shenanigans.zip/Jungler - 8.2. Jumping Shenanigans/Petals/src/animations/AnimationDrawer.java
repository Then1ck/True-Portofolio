package animations;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class AnimationDrawer {
	public ArrayList<Animates> Animations;
	public int State = 0;
	
	public AnimationDrawer(ArrayList<Animates> animations) {
		Animations = animations;
	}
	
	public void changeState(int state) {
		if(State==state)return;
//		System.out.println("New State == " + state);
		if(Animations.get(State) instanceof NextAnimation) {
			if(((NextAnimation)Animations.get(State)).StateTo==state)return;
		}
		Animations.get(State).Counter=Animations.get(State).MaxCounter;
		Animations.get(State).X = Animations.get(State).StartX;
		Animations.get(State).Y = Animations.get(State).StartY;
		State = state;
	}
	
	public int draw(Graphics2D g2, int locX, int locY, boolean left) {
		return Animations.get(State).draw(g2, locX, locY, left);
	}
	
}
