package animations;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;

public class FinAnimation extends Animates{

	public boolean left;
	public FinAnimation(BufferedImage sprite, int startX, int startY, int endX, int endY, int maxCounter,
			int spriteSizeX, int spriteSizeY, double scale, int locX, int locY, boolean left) {
		super(sprite, startX, startY, endX, endY, maxCounter, spriteSizeX, spriteSizeY, scale);
		// TODO Auto-generated constructor stub
		this.locX = locX;
		this.locY = locY;
		this.left = left;
	}
	@Override
	public int draw(Graphics2D g2, int locX, int locY, boolean left) {
		if(left) g2.drawImage(sprite, locX, locY, locX+ScaledSpriteX, locY+ScaledSpriteY, X+SpriteSizeX, Y, X, Y+SpriteSizeY, null);
		else g2.drawImage(sprite, locX, locY, locX+ScaledSpriteX, locY+ScaledSpriteY, X, Y, X+SpriteSizeX, Y+SpriteSizeY, null);
		
		if(Counter>0) {
			Counter--;
			return 0;
		}
		Counter = MaxCounter;
//		System.out.println(X + " " + Y + " " + SpriteSizeX + " " + SpriteSizeY);
		if(X+SpriteSizeX<EndX) {
			X+=SpriteSizeX;
		}else if(Y+SpriteSizeY<EndY) {
			Y+=SpriteSizeY;
			X=StartX;
		}else {
			return 1;
		}
		return 0;
		
	}
	
	public int drawR(Graphics2D g2, int locX, int locY) {
		if(left) g2.drawImage(sprite, locX+10, locY, locX+ScaledSpriteX, locY+ScaledSpriteY, X+SpriteSizeX, Y, X, Y+SpriteSizeY, null);
		else g2.drawImage(sprite, locX+10, locY, locX+ScaledSpriteX, locY+ScaledSpriteY, X, Y, X+SpriteSizeX, Y+SpriteSizeY, null);
		
		if(Counter>0) {
			Counter--;
			return 0;
		}
		Counter = MaxCounter;
//		System.out.println(X + " " + Y + " " + SpriteSizeX + " " + SpriteSizeY);
		if(X+SpriteSizeX<EndX) {
			X+=SpriteSizeX;
		}else if(Y+SpriteSizeY<EndY) {
			Y+=SpriteSizeY;
			X=StartX;
		}else {
			return 1;
		}
		
		Random rand = new Random();
		this.locX += rand.nextInt(9)-4;
		this.locY += rand.nextInt(9)-4;

		return 0;
	}

}
