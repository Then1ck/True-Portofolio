package animations;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public abstract class Animates {
	public BufferedImage sprite;
	public int StartX, StartY, EndX, EndY, X, Y, locX, locY;
	public int Counter, MaxCounter, SpriteSizeX, SpriteSizeY, ScaledSpriteX, ScaledSpriteY;
	public double Scale;
	
	public Animates(BufferedImage sprite, int startX, int startY, int endX, int endY, int maxCounter,
			int spriteSizeX, int spriteSizeY, double scale) {
		super();
		this.sprite = sprite;
		StartX = startX;
		StartY = startY;
		EndX = endX;
		EndY = endY;
		X = startX;
		Y = startY;
		Counter = maxCounter;
		MaxCounter = maxCounter;
		SpriteSizeX = spriteSizeX;
		SpriteSizeY = spriteSizeY;
		Scale = scale;
		ScaledSpriteX = (int)(SpriteSizeX*Scale);
		ScaledSpriteY = (int)(SpriteSizeY*Scale);
	}
	
	public abstract int draw(Graphics2D g2, int locX, int locY, boolean left);
	
}
