package animations;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class TempAnimation {
	public BufferedImage spriteSheet;
	public ArrayList<Integer> max;
	public int State = 0;
	public int SpriteSize = 32;
	public int X = 0, Y = 0;
	public double scale;
	public int counter = 10;

	public TempAnimation(BufferedImage spriteSheet, ArrayList<Integer> Max, double Scale) {
		this.spriteSheet = spriteSheet;
		max = Max;
		scale = Scale;
	}
		
	public void Animating(Graphics2D g2, int locX, int locY) {
		System.out.println(locX + " " + locY);
		System.out.println(X + " " + Y);
		System.out.println(X + " " + spriteSheet.getWidth() + " " + Y + " " + spriteSheet.getHeight());
		
		g2.drawImage(spriteSheet, locX, locY-(int)(SpriteSize*scale), locX+(int)(SpriteSize*scale), 
				locY, X, Y, X+SpriteSize, Y+SpriteSize, null);
		
		if(counter > 0) {
			counter--;
			return;
		}
		counter = 10;
		if(X+SpriteSize<max.get(4*State+2)) {
			X+=SpriteSize;
		}else if(Y+SpriteSize<max.get(4*State+3)){
			Y+=SpriteSize;
			X = max.get(4*State);
		}else {
			Y=max.get(4*State+1);
			X = max.get(4*State);
		}
	}
}
