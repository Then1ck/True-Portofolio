package animations;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class NextAnimation extends Animates{

	public int StateTo;
	
	public NextAnimation(BufferedImage sprite, int startX, int startY, int endX, int endY, int maxCounter,
			int spriteSizeX, int spriteSizeY, double scale, int stateTo) {
		super(sprite, startX, startY, endX, endY, maxCounter, spriteSizeX, spriteSizeY, scale);
		// TODO Auto-generated constructor stub
		StateTo = stateTo;
	}
	
	
	@Override
	public int draw(Graphics2D g2, int locX, int locY, boolean left) {
		if(left) g2.drawImage(sprite, locX, locY-(int)(ScaledSpriteY), locX+(int)(ScaledSpriteX), locY, X+SpriteSizeX, Y, X, Y+SpriteSizeY, null);
		else g2.drawImage(sprite, locX, locY-(int)(ScaledSpriteY), locX+(int)(ScaledSpriteX), locY, X, Y, X+SpriteSizeX, Y+SpriteSizeY, null);
		
		if(Counter>0) {
			Counter--;
			return -1;
		}
		Counter = MaxCounter;
//		System.out.println(X + " " + Y + " " + SpriteSizeX + " " + SpriteSizeY);
		if(X+SpriteSizeX<EndX) {
			X+=SpriteSizeX;
		}else if(Y+SpriteSizeY<EndY) {
			Y+=SpriteSizeY;
			X=StartX;
		}else {
			return StateTo;
		}
		
		return -1;
	}
	

}
