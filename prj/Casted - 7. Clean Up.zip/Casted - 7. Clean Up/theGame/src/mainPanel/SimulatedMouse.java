package mainPanel;

import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import controls.MouseMovements;

public class SimulatedMouse {
	private BufferedImage ShooterArt, CursorArt, CurrArt;
	private MouseMovements MouseM;
	private int sMouseX=0, sMouseY=0;
	private Robot resetMouse;
	private JFrame mainFrame;
	private int adjusment, halfScreenX, halfScreenY, screenX, screenY, cursorSize;

	public SimulatedMouse(MouseMovements mouseM, JFrame _mainFrame, GamePanel _gp, int _cursorSize) {
		super();
		this.MouseM = mouseM;
		this.mainFrame = _mainFrame;
		try {
			this.resetMouse = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		try {
			ShooterArt = ImageIO.read(getClass().getResourceAsStream("/cursors/mouseType.png"));
			CursorArt = ImageIO.read(getClass().getResourceAsStream("/cursors/PtrCursor.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		CurrArt = ShooterArt;
		sMouseX = 640;
		sMouseY = 360;
		adjusment = -16;
		this.halfScreenX = _gp.getWidth()/2;
		this.halfScreenY = _gp.getHeight()/2;
		this.screenX = _gp.getWidth();
		this.screenY = _gp.getHeight();
		this.cursorSize = _cursorSize;
	}
	
	public int LimitX(int change) {
		int temp = sMouseX-change;
		if(temp<0)return 0;
		if(temp>=screenX)return screenX-1;
		return temp;
	}
	public int LimitY(int change) {
		int temp = sMouseY-change;
		if(temp<0)return 0;
		if(temp>=screenY)return screenY-1;
		return temp;
	}
	
	public void Reset() {
//		System.out.println("Reset: " + MouseM.getMouseX() + ", " + MouseM.getMouseY());
		sMouseX = LimitX(halfScreenX - MouseM.getMouseX());
		sMouseY = LimitY(halfScreenY - MouseM.getMouseY());
		resetMouse.mouseMove(mainFrame.getX()+halfScreenX+8, mainFrame.getY()+halfScreenY+31);
	}
	
	public void LayOver() {
		sMouseX = MouseM.getMouseX();
		sMouseY = MouseM.getMouseY();
	}
	
	public void swapCursor() {
		if(CurrArt == ShooterArt) {
			CurrArt = CursorArt;
			resetMouse.mouseMove(mainFrame.getX()+sMouseX+8, mainFrame.getY()+sMouseY+31);
			adjusment = 0;
		}else {
			CurrArt = ShooterArt;
			resetMouse.mouseMove(mainFrame.getX()+halfScreenX+8, mainFrame.getY()+halfScreenY+31);
			adjusment = -cursorSize/2;
//			System.out.println("Swapped: " + MouseM.getMouseX() + ", " + MouseM.getMouseY());
		}
	}
	
	public int getSMouseX() {
		return sMouseX;
	}
	
	public int getSMouseY() {
		return sMouseY;
	}
	
	public void draw(Graphics2D g2) {
		g2.drawImage(CurrArt, sMouseX+adjusment, sMouseY+adjusment, cursorSize, cursorSize, null);
	}
	
	public int getAdjustment() {
		return adjusment;
	}
}
