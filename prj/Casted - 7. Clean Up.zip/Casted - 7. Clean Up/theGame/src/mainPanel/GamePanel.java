package mainPanel;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import controls.KeyboardInputs;
import controls.MouseInputs;
import controls.MouseMovements;
import controls.MouseWheelInputs;
import entities.Player;
import game.Game;
import hitboxes.FloorCheck;
import room.CreateRoomFloor;
import weapon.Gun1;
import weapon.Gun2;
import weapon.Gun3;
import weapon.Projectiles;
import weapon.RangedWeapons;
import weapon.Weapons;

public class GamePanel extends JPanel implements Runnable{
	private int screenWidth, screenHeight, tileSize;
	private double scale = 1;
	private Thread gameThread;
	private JFrame mainFrame;
	
	private KeyboardInputs KeyI;
	private MouseInputs MouseI;
	private MouseMovements MouseM;
	private MouseWheelInputs MouseW;
	
	private int FPS = 60;
	
	private Game runGame;

	public GamePanel(JFrame _mainFrame) {
		this.mainFrame = _mainFrame;
		
		//Declare window size
		screenWidth = 1280;
		screenHeight = 720;
		tileSize = 64;
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		
		//Sets settings
		this.setFocusable(true);
		this.setDoubleBuffered(true);
		this.setBackground(Color.DARK_GRAY);
		
		//declare controls
		this.KeyI = new KeyboardInputs();
		this.MouseI = new MouseInputs();
		this.MouseM = new MouseMovements();
		this.MouseW = new MouseWheelInputs(this);
		
		//add controls listener
		this.addKeyListener(KeyI);
		this.addMouseListener(MouseI);
		this.addMouseMotionListener(MouseM);
		this.addMouseWheelListener(MouseW);
		
		runGame = new Game(this, KeyI, MouseI, MouseM, mainFrame);
	}
	
	public Game getGame() {
		return runGame;
	}
	
	public int getWidth() {
		return screenWidth;
	}
	
	public int getHeight() {
		return screenHeight;
	}
	
	public int getTileSize() {
		return tileSize;
	}
	
	public void startGameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	@Override
	public void run() {
		double drawSpeed = 1000000000/FPS;
		double delta=0;
		
		long prevTime = System.nanoTime();
		long newTime = System.nanoTime();
		
		while(gameThread!=null) {
			newTime = System.nanoTime();
			delta += (newTime-prevTime)/drawSpeed;
			prevTime = newTime;
			
			if(delta>=1) {
				runGame.update();
				repaint();
				delta--;
			}
		}
		
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		runGame.drawAll(g2);
		
		runGame.drawMouse(g2);
		
//		g2.drawImage(testArt, 0, 0, 64, 32, 0, 0, 16, 8, null); //Partial drawing
		//Split object / wall map into 2 : above player and below player, depending on players position
		
		g2.dispose();
	}
	
}

//Movement controls, pause menu, change controls, auto hold
