package entities;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import animation.LoopAnimation;
import animation.SwingAnimation;
import mainPanel.Camera;

public class Player extends Entity{

	private LoopAnimation Idle;
	private SwingAnimation Walk;
	private int state;
	private int diveTimer;
	
	public Player(Camera cams, int limitX, int limitY) {
		super(144, 144, 8, 100, cams, limitX, limitY);
		ArrayList<BufferedImage> temp = new ArrayList<BufferedImage>();
		try {
			temp.add(ImageIO.read(getClass().getResourceAsStream("/entity/Striker.png")));
			temp.add(ImageIO.read(getClass().getResourceAsStream("/entity/Striker.png")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Idle = new LoopAnimation(temp, 32, 32);
		Walk = new SwingAnimation(temp, 0, 32, 32);
		state = 0;
		diveTimer = 0;
//		setLBox(16, 31, 8, 24);
		setLBox(0, 15, -8, 8); // above but all -16 because playerLoc is at the center not top-left
	}
	
	public void MoveX(int X) {
		this.WorldX += X;
		if(WorldX+super.LBox.getLeft()<0)WorldX = -LBox.getLeft();
		if(WorldX+super.LBox.getRight()>=LimitX)WorldX = LimitX - LBox.getRight()-1;
	}
	
	public void MoveY(int Y) {
		this.WorldY += Y;
		if(WorldY+super.LBox.getUp()<0)WorldY = -LBox.getUp();
		if(WorldY+super.LBox.getDown()>=LimitY)WorldY = LimitY - LBox.getDown()-1;
	}
	
	public void changeState(int newState) {
		state = newState;
	}
	
	public void draw(Graphics2D g2) {
		switch(state) {
		case 0://Idle
			Idle.Animate(g2, WorldX-Cams.getCamX(), WorldY-Cams.getCamY());
			break;
		case 1:
			Walk.Animate(g2, WorldX-Cams.getCamX(), WorldY-Cams.getCamY());
			break;
		}
	}
	
	public void setSpeed(int speed) {
		super.MaxSpeed = speed;
	}
	
	public int getSpeed() {
		return super.MaxSpeed;
	}
	
	private double diveSpeedX, diveSpeedY;
	
	public void dive(int x, int y) {
		if(x-WorldX==0) {
			diveSpeedX = 0;
			diveSpeedY = 32;
			diveTimer = 10;
		}else {
			double m = (double)(y-WorldY)/(double)(x-WorldX);
			double c = Math.sqrt((32*32)/(1+m*m));
			diveSpeedX = c;
			diveSpeedY = c*m;
			diveTimer = 10;
		}
		
		if(x < WorldX) {
			diveSpeedX = -diveSpeedX;
			diveSpeedY = -diveSpeedY;
		}
	}
	
	public boolean diveCheck() {
		if(diveTimer==0)return false;
		diveTimer--;
		MoveX((int)diveSpeedX);
		MoveY((int)diveSpeedY);
		return true;
		
	}
	
}
