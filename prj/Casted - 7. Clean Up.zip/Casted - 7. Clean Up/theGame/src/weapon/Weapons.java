package weapon;

public abstract class Weapons {
	protected int Damage, Range;
	protected boolean StrikeThrough;
	
	public abstract boolean countDown();
}
