/**
 * 
 */
/**
 * 
 */
module theGame {
	requires java.desktop;
}